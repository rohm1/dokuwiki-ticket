<?php
/**
 * Options for the ticket plugin
 *
 * @author Romain Perez <rp@rohm1.com>
 */


$meta['url'] = array('string');
$meta['targetBlank'] = array('onoff');
