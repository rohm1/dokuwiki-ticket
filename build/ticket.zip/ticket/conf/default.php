<?php
/**
 * Default settings for the ticket plugin
 *
 * @author Romain Perez <rp@rohm1.com>
 */

$conf['url']    = 'http://your-ticket-system.net/ticket-%s';
